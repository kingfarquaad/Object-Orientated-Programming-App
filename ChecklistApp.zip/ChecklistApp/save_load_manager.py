import pickle
import os

class SaveLoadManager():
    def save(self, users):
        "Called whenever something is changed, saves to binary file using pickle"
        with open("savefile.bin", "wb") as f: # "wb" because we want to write in binary mode
            pickle.dump(users, f)

    def load(self):
        "Called on login, loads all saved data from binary file using pickle"
        if os.path.isfile("savefile.bin") == False:
            with open("savefile.bin", "wb") as f: # "wb" because we want to write in binary mode
                pickle.dump({}, f)
        with open("savefile.bin", "rb") as f: # "rb" because we want to read in binary mode
            return (pickle.load(f))