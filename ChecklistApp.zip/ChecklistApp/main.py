from kivy.config import Config
Config.set('input', 'mouse', 'mouse,multitouch_on_demand')
import os, sys
from kivy.resources import resource_add_path

import checklist_manager as chckmng
import header_manager as hdrmng
import user_manager as usrmng
from kivy.app import App
from modules import MainLayout


class MyApp(App):
    def build(self):
        "Main function, runs app, is called by the last line of this script"
        root = MainLayout()
        usrmng.UserManager().load_users(root)
        chckmng.ChecklistManager().setup(root)
        hdrmng.HeaderManager().setup(root)
        return root

MyApp().run()