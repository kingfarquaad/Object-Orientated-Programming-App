from enum import IntEnum
import enums as enums

Priority = IntEnum('Priority', ['Low', 'Medium', 'High'])

ChecklistVariables = IntEnum('ChecklistVariables', ['description', 'time_date_added', 'time_date_due','priority', 'optional_label'])