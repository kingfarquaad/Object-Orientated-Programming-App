def default_font_size():
    return 16