import user_manager as usermng
import checklist_manager as chckmng
from modules import CustomBoxLayout
from kivy.uix.button import Button
from kivymd.uix.behaviors import HoverBehavior

class HeaderManager():
    login_button = None
    header = None
    def setup(self, root):
        HeaderManager.header= root.ids["header"]
    
    def show_edit_and_delete_buttons(self):
        "Makes the edit and delete button visible on header"
        HeaderManager.header.ids.get("delete_button").disabled = False
        HeaderManager.header.ids.get("edit_button").disabled = False

    def hide_edit_and_delete_buttons(self):
        "Hides the edit and delete button on header"
        HeaderManager.header.ids.get("delete_button").disabled = True
        HeaderManager.header.ids.get("edit_button").disabled = True
    
#region Header Modules
class HeaderLayout(CustomBoxLayout):
    def on_login_button_press(event = None):
        "Tells the user manager that the user button has been selected"
        user_manager = usermng.UserManager()
        user_manager.on_login_button_press()

    def on_new_checklist_button_press(event):
        "Tells the checklist manager that the new checklist item button has been pressed"
        chckmng.ChecklistManager().show_checklist_popup()

    def on_delete_checklist_button_press(event):
        "Tells the checklist manager that the delete checklist item button has been pressed"
        chckmng.ChecklistManager().delete_current_checklist_item()
        
    def on_edit_checklist_button_press(event):
        "Tells the checklist manager that the edit checklist item button has been pressed"
        chckmng.ChecklistManager().show_checklist_popup()

class HeaderButton(Button, HoverBehavior):
    def on_enter(self, *args):
        "Called on mouse enter, sets bg colour"
        self.background_color = (1, 1, 1, 0.8)

    def on_leave(self, *args):
        "Called on mouse exit, sets bg colour"
        self.background_color = (1, 1, 1, 1)
#endregion