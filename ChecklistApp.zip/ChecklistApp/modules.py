from kivy.properties import ColorProperty
from kivy.uix.gridlayout import GridLayout
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivymd.uix.behaviors import HoverBehavior
from kivy.uix.popup import Popup

#region Abstract Modules
"""
All classes here are base abstract UI Widgets, they are then used by other classes to create
specific derived versions
"""
class CustomLabel(Label):
    background_color = ColorProperty()

class CustomBoxLayout(BoxLayout):
    background_color = ColorProperty()

class CustomGridLayout(GridLayout):
    background_color = ColorProperty()
    
class CustomButton(Button, HoverBehavior):
    pass

class CustomPopUp(Popup):
    pass
#endregion

#region Main Module
"""Main Layout serves as the root widget, essentially the window."""
class MainLayout(BoxLayout): pass
#endregion