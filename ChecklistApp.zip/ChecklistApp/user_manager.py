import checklist_manager as chkmng
import header_manager as hdrmng
from modules import CustomPopUp
from save_load_manager import SaveLoadManager

class UserManager():
    __current_pop_up_panel = None
    current_user = None

    __users = {}

    def load_users(self, root):
        "Called on startup of app, loads all saved users and their associated checklist items"
        UserManager.__users= SaveLoadManager().load()

    def on_login_button_press(self):
        "Called by header manager, determines whether to open login popup or user popup"
        if UserManager.current_user == None:
            self.show_login_panel()
        else: 
            self.__show_user_panel()

    def show_login_panel(self):
        "Opens login popup"
        self.close_all_panels()

        popup_window= LoginPopUp(auto_dismiss = False)
        UserManager.__current_pop_up_panel = popup_window
        popup_window.open()

    def try_login(self, username, password, error_label):
        "Called by login button on login popup, if all inputs are correct, logs in, otherwise shows appropriate error message"
        error_label.text= ""
        if  username == "":
            error_label.text= "Username required!"
            return
        
        if password == "":
            error_label.text= "Password required!"
            return
        
        if UserManager.__users.get(username) == None:
            error_label.text= "Username not found!"
            return
        
        if UserManager.__users[username].password != password:
            error_label.text= "Incorrect password!"
            return

        error_label.text= ""
        self.__log_in(UserManager.__users[username]) 

    def __log_in(self, user):
        "Called by try login, logs user in"
        UserManager.current_user = user
        self.__show_user_panel()
        chkmng.ChecklistManager().refresh_checklists()

    def log_out(self):
        "Called by user panel on logout press"
        UserManager.current_user = None
        UserManager().show_login_panel()
        chkmng.ChecklistManager().refresh_checklists()
        hdrmng.HeaderManager().hide_edit_and_delete_buttons()

    def  __show_user_panel(self):
        "Opens current user popup"
        self.close_all_panels()
        
        popup_window= UserPopUp()
        UserManager.__current_pop_up_panel = popup_window
        popup_window.open()

    def try_create_new_user(self, username, password, error_message_label):
        "Called by create new user button on login popup, if all inputs are correct, creates new user, otherwise shows appropriate error message"
        if  username == "":
            error_message_label.text= "Username required!"
            return
        
        if password == "":
            error_message_label.text= "Password required!"
            return
        
        if UserManager.__users.get(username) != None:
            error_message_label.text= "Username already exists!"
            return
        
        UserManager.__users[username] = User(username, password)
        SaveLoadManager().save(UserManager.__users)
        self.__log_in(UserManager.__users[username])

    def close_all_panels(self):
        "Closes all popups"
        if UserManager.__current_pop_up_panel == None: return
        self.__current_pop_up_panel.dismiss()

    def delete_checklist_item(self, checklist_item_to_delete):
        "Removes checklist item from user"
        user = self.current_user
        if checklist_item_to_delete in user.checklist_items:
            user.checklist_items.remove(checklist_item_to_delete)

    def user_checklists_changed(self, new_checklist_item = None):
        "Called when checklist item edited or added for user, changes checklist item and saves new information"
        user = self.current_user
        if (user == None): return
        if (new_checklist_item != None): user.checklist_items.append(new_checklist_item)
        SaveLoadManager().save(UserManager.__users)

#region User
class User():
    "User class, used to store all information for each user"
    def __init__(self, username: str, password: str):
        self.username = username
        self.password = password
        self.checklist_items = []

    def update_users_checklists(self, checklist_items):
        "Called when checklist items are changed (including added)"
        self.checklist_items = checklist_items
#endregion

#region LogIn Widgets
class LoginPopUp(CustomPopUp):
    "UI class, derives from Kivy popup"
    def on_close_press(self):
        "Closes popup"
        UserManager().close_all_panels()
    
    def on_login_press(self, username, password):
        "Tries login"
        error_message_label = self.ids.get("error_text")
        UserManager().try_login(username, password, error_message_label)

    def on_create_new_user_press(self, username, password):
        "Shows error message on popup"
        error_message_label = self.ids.get("error_text")
        UserManager().try_create_new_user(username, password, error_message_label)

class UserPopUp(CustomPopUp):
    "UI class, derives from Kivy popup"
    def on_close_press(self):
        "Closes popup"
        UserManager().close_all_panels()

    def on_logout_press(self):
        "Logs user out"
        UserManager().log_out()

    def get_current_user(self):
        "Gets current user"
        return UserManager.current_user
#endregion