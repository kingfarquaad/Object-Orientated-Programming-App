import user_manager as usermng
import header_manager as headermng
from modules import CustomBoxLayout
from modules import CustomPopUp
from kivy.uix.button import Button
from kivymd.uix.behaviors import HoverBehavior
from enums import *
from datetime import datetime

class ChecklistManager():
    instantiated_checklist_boxes = []

    checklist_item_ins_point = None
    pop_up_checklist_panel = None

    current_sort_variable = None
    current_selected_checklist_box = None

    def setup(self, root):
        """Called by the main loop before the app has loaded, gets the instantiate point for all checklist items from the .kv file"""
        ChecklistManager.checklist_item_ins_point = root.ids["checklistpanel"].ids['scrollview_instantiate_point']

    def create_new_checklist_item(self, description, due_date, priority, label):
        """
        Called by new checklist popup, creates a new item class, 
        sends it to the UserManager to be saved to user, 
        then tells the UI to refresh itself and instantiate a UI element to represent the item
        """
        checklist_item = ChecklistItem(description, due_date, priority, label)
        usermng.UserManager().user_checklists_changed(checklist_item)
        self.refresh_checklists()
    
    def checklist_box_selected(self, checklist_box):
        """Called when an instantiated checklist UI widget is clicked"""
        ChecklistManager.current_selected_checklist_box = checklist_box
        headermng.HeaderManager().show_edit_and_delete_buttons()
    
    def checklist_box_deselected(self, checklist_box):
        """Called when an instantiated checklist UI widget is deselceted"""
        if ChecklistManager.current_selected_checklist_box != checklist_box: return
        ChecklistManager.current_selected_checklist_box = None
        headermng.HeaderManager().hide_edit_and_delete_buttons()

    def edit_checklist_item(self, checklist_item, description, priority, label):
        """Called by the edit checklist popup, edits the checklist item, sends it to UserManager to be saved, then refreshes UI"""
        checklist_item.edit(description, priority, label)
        usermng.UserManager().user_checklists_changed()
        ChecklistManager().checklist_box_deselected(ChecklistManager.current_selected_checklist_box)
        self.refresh_checklists()

    def delete_current_checklist_item(self):
        """Called by the edit checklist popup, tells the UserManager to remove the checklist item from the user thus deleting it, then refreshes UI"""
        if ChecklistManager.current_selected_checklist_box == None: return
        usermng.UserManager().delete_checklist_item(ChecklistManager.current_selected_checklist_box.checklist_item)
        usermng.UserManager().user_checklists_changed()
        ChecklistManager().checklist_box_deselected(ChecklistManager.current_selected_checklist_box)
        self.refresh_checklists()

    def refresh_checklists(self):
        """
        Refreshes the current checklist UI widgets shown.
        Deletes all instantiated UI widgets, gets the current user, gets their checklist items, and instantiates new UI widgets for each one
        """
        ChecklistManager.checklist_item_ins_point.clear_widgets()
        if usermng.UserManager().current_user == None: return
        for checklist_item in usermng.UserManager().current_user.checklist_items:
            checklist_box= ChecklistBox(checklist_item)
            ChecklistManager().checklist_item_ins_point.add_widget(checklist_box)
            ChecklistManager().instantiated_checklist_boxes.append(checklist_box)

    def sort_checklist_order(self, sort_type: ChecklistVariables):
        """Sorts the checklist by a specific variable."""
        current_user = usermng.UserManager().current_user
        if current_user == None: return
        current_user_checklist_items= current_user.checklist_items
        if current_user_checklist_items == None: return

        if ChecklistManager.current_sort_variable == None or ChecklistManager.current_sort_variable != sort_type: 
            current_user_checklist_items.sort(key=lambda x: x.get_variable_to_sort_with(sort_type), reverse=False)
        else: 
            current_user_checklist_items.reverse()
        ChecklistManager.current_sort_variable = sort_type
        self.refresh_checklists()
    
    def show_checklist_popup(self):
        """Determines whether to show a create new checklist popup, or an edit current checklist popup"""
        if usermng.UserManager().current_user == None:       
            usermng.UserManager().show_login_panel()
            return
        
        popup_window = None
        current_selected_checklist_box = ChecklistManager.current_selected_checklist_box
        if (current_selected_checklist_box == None): popup_window= NewChecklistPopUp()
        else: popup_window= EditChecklistPopUp(current_selected_checklist_box.checklist_item)
        ChecklistManager.pop_up_checklist_panel = popup_window
        popup_window.open()

    def close_new_checklist_popup(self):
        """If there is an open popup, closes it"""
        if ChecklistManager.pop_up_checklist_panel == None: return
        self.pop_up_checklist_panel.dismiss()

#region Checklist Item
class ChecklistItem():
    def __init__(self, description: str, due_date: datetime.date, priority: Priority, optional_label: str):
        self.edit(description, due_date, priority, optional_label)

    def edit(self, description: str, due_date: datetime.date, priority: Priority, optional_label: str):
        """Called to edit the current checklist item"""
        self.description = description
        self.time_date_added = datetime.now()
        self.time_date_due = due_date
        self.priority = priority
        self.optional_label = optional_label

    def get_variable_to_sort_with(self, variable: ChecklistVariables):
        """
        Returns a variable to use when sorting the checklist items.
        This is so that when you sort by priority, it uses the integer value of the enum rather than doing it alphabetically
        """
        if hasattr(self, variable.name): 
            if (variable == ChecklistVariables.priority): return getattr(self, variable.name).value
            return getattr(self, variable.name)
        else: return ""
#endregion
    
#region Checklist Widgets
class ChecklistPopUp(CustomPopUp):
    """Abstract class to be used by the new checklist and edit checklist popups"""
    def on_close_press(self):
        ChecklistManager().close_new_checklist_popup()

class NewChecklistPopUp(ChecklistPopUp):
    title= "Add New"
    due_date = None
    due_month = None
    due_year = None
    
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.ids.get("add_or_edit").text = "Add"
    
    def on_add_or_edit_press(self, description, priority, optional_label):
        "Called by the Add button on the New Checklist Pop Up, attempts to add new checklist item"
        if self.due_year < 1900: self.due_year = 1900
        if description == "":
            self.ids.get("error_text").text = "You didn't enter a description!"
            return 
        elif self.due_date == None or self.due_month == None or self.due_year == None:
            self.ids.get("error_text").text = "You didn't enter a date!"
            return 
        try:
            date = datetime(self.due_year, self.due_month, self.due_date)
        except ValueError:
            self.ids.get("error_text").text = "Incorrect date format!"
            return
        if date < datetime.today(): 
            self.ids.get("error_text").text = "Due date can't be before today!"
            return
        ChecklistManager().create_new_checklist_item(description,
                                                    date,
                                                    Priority[priority], 
                                                    optional_label)
        ChecklistManager().close_new_checklist_popup()

    def on_due_date_text_change(self, input_box, input_text):
        "Called whenever the text on the due date on the popup changes"
        input_text = input_text[:2]
        input_text = self.limit_to_numbers(input_text)
        input_box.text = self.limit_to_numbers(input_text)
        if len(input_text) > 0: self.due_date = int(input_text)
        else: self.due_date = None

    def on_due_month_text_change(self, input_box, input_text):
        "Called whenever the text on the due month on the popup changes"
        input_text = input_text[:2]
        input_text = self.limit_to_numbers(input_text)
        input_box.text = self.limit_to_numbers(input_text)
        if len(input_text) > 0: self.due_month = int(input_text)
        else: self.due_month = None

    def on_due_date_year_change(self, input_box, input_text):
        "Called whenever the text on the due year on the popup changes"
        input_text = input_text[:4]
        input_text = self.limit_to_numbers(input_text)
        input_box.text = self.limit_to_numbers(input_text)
        if len(input_text) > 0: self.due_year = int(input_text)
        else: self.due_year = None

    def limit_to_numbers(self, text):
        "Returns a string that contains integers only"
        limited_text = ""
        for character in text:
            if not character.isdigit(): continue
            limited_text += character
        return limited_text

class EditChecklistPopUp(ChecklistPopUp):
    title= "Edit"

    def __init__(self, checklist_item: ChecklistItem, **kwargs):
        super().__init__(**kwargs)
        self.ids.get("add_or_edit").text = "Change"
        self.ids.get("description").text = checklist_item.description
        self.ids.get("dropdown_button").text = checklist_item.priority.name
        self.ids.get("optional_label").text = checklist_item.optional_label
        self.checklist_item = checklist_item

    def on_edit_press(self, description, priority, optional_label):
        "Called by edit checklist pop up, changes preexisting checklist item"
        if description == "":
            self.ids.get("error_text").text = "You didn't enter a description!"
            return 
            
        ChecklistManager().edit_checklist_item(self.checklist_item, description, Priority[priority], optional_label)
        ChecklistManager().close_new_checklist_popup()

class ChecklistPanel(CustomBoxLayout):
    pass

class ChecklistHeaderButton(Button):
    checklist_variable = ""
    height: 20

    def on_press(event):
        ChecklistManager().sort_checklist_order(ChecklistVariables[event.checklist_variable])

class ChecklistBox(CustomBoxLayout, HoverBehavior):
    __on_hover_selected_colour = (0.7, 0.7, 0.7, 1)
    __on_hover_not_selected_colour = (0.9, 0.9, 0.9, 1)
    __on_leave_selected_colour = (0.8, 0.8, 0.8, 1)
    __on_leave_not_selected_colour =  (1 ,1, 1, 1)

    def __init__(self, checklist_item:ChecklistItem, **kwargs):
        self.checklist_item = checklist_item
        self.is_currently_selected = False
        super().__init__(**kwargs)

    def on_enter(self, *args):
        "Called on mouse enter, changes colour of bg"
        if self.is_currently_selected: self.background_color = ChecklistBox.__on_hover_selected_colour
        else: self.background_color = ChecklistBox.__on_hover_not_selected_colour

    def on_touch_down(self, touch):
        "Called on click, determines if self is being clicked, and if so, changes colour and tells the checklist manager, if not, reverts bg colour to default"
        if self.collide_point(*touch.pos) == False:
            self.is_currently_selected = False
            self.background_color = ChecklistBox.__on_leave_not_selected_colour
            ChecklistManager().checklist_box_deselected(self)
            return

        self.is_currently_selected = True
        self.background_color = ChecklistBox.__on_hover_selected_colour
        ChecklistManager().checklist_box_selected(self)
        ChecklistManager().checklist_box_selected(self)

        if touch.is_double_tap == False: return
        ChecklistManager().show_checklist_popup()

    def on_leave(self, *args):
        "Called on mouse leave, resets bg colour to correct colour"
        if self.is_currently_selected: self.background_color = ChecklistBox.__on_leave_selected_colour
        else: self.background_color = ChecklistBox.__on_leave_not_selected_colour

    def get_value(self, value_name):
        "Returns a value for a given variable name"
        if (self.ids.get(value_name) == None): return
        return self.ids[value_name]
#endregion